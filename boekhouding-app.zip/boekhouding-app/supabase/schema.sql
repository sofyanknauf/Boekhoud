-- Boekhouding: database, beveiliging en opslag voor bonnetjes.
-- Plak dit in Supabase → SQL Editor en klik op Run. Je kunt het veilig vaker uitvoeren.

-- 1. Eén tabel voor alle gegevens (facturen, transacties, klanten, uren, ...)
create table if not exists public.records (
  user_id    uuid        not null default auth.uid() references auth.users(id) on delete cascade,
  kind       text        not null check (kind in ('settings','tx','inv','off','klant','invest','uren')),
  id         text        not null,
  data       jsonb       not null,
  updated_at timestamptz not null default now(),
  primary key (user_id, kind, id)
);

create or replace function public.touch_updated_at() returns trigger
language plpgsql as $$ begin new.updated_at = now(); return new; end $$;

drop trigger if exists records_touch on public.records;
create trigger records_touch before update on public.records
  for each row execute function public.touch_updated_at();

-- 2. Row Level Security: iedereen ziet en wijzigt alleen zijn eigen gegevens
alter table public.records enable row level security;

drop policy if exists "eigen records lezen"    on public.records;
drop policy if exists "eigen records maken"    on public.records;
drop policy if exists "eigen records wijzigen" on public.records;
drop policy if exists "eigen records wissen"   on public.records;

create policy "eigen records lezen"    on public.records for select to authenticated using (user_id = auth.uid());
create policy "eigen records maken"    on public.records for insert to authenticated with check (user_id = auth.uid());
create policy "eigen records wijzigen" on public.records for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "eigen records wissen"   on public.records for delete to authenticated using (user_id = auth.uid());

-- 3. Live bijwerken tussen telefoon en computer
do $$ begin
  alter publication supabase_realtime add table public.records;
exception when duplicate_object then null; end $$;

-- 4. Privé-opslag voor bonnetjes (elke gebruiker alleen zijn eigen map)
insert into storage.buckets (id, name, public)
values ('bonnetjes', 'bonnetjes', false)
on conflict (id) do nothing;

drop policy if exists "eigen bonnetjes lezen"    on storage.objects;
drop policy if exists "eigen bonnetjes uploaden" on storage.objects;
drop policy if exists "eigen bonnetjes wissen"   on storage.objects;

create policy "eigen bonnetjes lezen" on storage.objects for select to authenticated
  using (bucket_id = 'bonnetjes' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "eigen bonnetjes uploaden" on storage.objects for insert to authenticated
  with check (bucket_id = 'bonnetjes' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "eigen bonnetjes wissen" on storage.objects for delete to authenticated
  using (bucket_id = 'bonnetjes' and (storage.foldername(name))[1] = auth.uid()::text);
